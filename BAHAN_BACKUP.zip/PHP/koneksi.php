<?php
$server ="localhost";
$username="root"; //username root adalah username default dari phpmyadmin
$password=""; // username root tidak menggunakan password.
$database="db_crud"; // nama database 

$koneksi = mysqli_connect($server,$username,$password,$database);


?>