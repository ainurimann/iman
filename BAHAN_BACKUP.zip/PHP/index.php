<!DOCTYPE html>
<html>
<head>
	<title>INDEX</title>
</head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<body>
	<table align="center" width="100%">
		<tr>
			<td>
				<center>INDEX</center>
			</td>
		</tr>
		<tr>
			<td>
				<table width="60%" align="center" style="border-radius: 15px; border: 5px solid black;" bgcolor="white">
					<tr>
						<td>
							 <p><h1 style="color: black; text-align: center;">Login</h1></p> 
      	  <p style="color: black; text-align: center;">Username : <input type="text" name="variable_username">
      	  <p style="color: black; text-align: center;">Password &nbsp;: <input type="text" name="variable_password"></p>
      	  <p style="color: black; text-align: center;"><input type="checkbox" name="variable_me">Remember Me</p>
      	  <p><center><button>&nbsp;&nbsp;&nbsp;Login&nbsp;&nbsp;&nbsp;</button></center></p>
						</td>
					</tr>
				</table>
	</table>
</body>
</html>