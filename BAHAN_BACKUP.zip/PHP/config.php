<?php
$server ="localhost";
$username="root"; //username root adalah username default dari phpmyadmin
$dbpassword=""; // username root tidak menggunakan password.
$database="db_crud"; // nama database 

$config = mysqli_connect($server,$username,$dbpassword,$database);


?>