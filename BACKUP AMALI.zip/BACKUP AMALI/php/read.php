<?php
require "koneksi.php";
$sql     = " SELECT * FROM table_crud";
$execute = mysqli_query($koneksi , $sql);
?>





<!DOCTYPE html>
<html>
<head>
  <style>
table {
  border-collapse: collapse;
  width: 100%;
  background-color: mistyrose;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {background-color: pink;}
</style>
  <title>Read Php</title>
</head>
<body>
  <a href="create.php">Add</a>
  <table border="1" width="50%">
    <thead>
      <th>id</th>
      <th>nama</th>
      <th>kelas</th>
      <th>action</th>
    </thead>
    <?php while($result =  mysqli_fetch_assoc($execute)){ ?>
    <tr>
      <td><?= $result['id'] ?></td>
      <td><?= $result['nama'] ?></td>
      <td><?= $result['kelas'] ?></td>
      <td> 
        <a href="update.php?id=<?= $result['id'] ?>">Update</a>
         |
        <a href="delete.php?id=<?= $result['id'] ?>">Delete</a>
        </td>
    </tr>
  <?php  }?>
  </table>

</body>
</html>