<?php 
require "koneksi.php";

if (isset($_POST['Add'])) {
	$val_nama = $_POST['input_nama'];
	$val_kelas =$_POST['input_kelas'];

	$sql = "INSERT INTO table_crud (nama,kelas) VALUES ('$val_nama','$val_kelas')";
	$execute = mysqli_query($koneksi , $sql);

	if ($execute){
		header('Location:read.php');
	} else{
		echo "GAGAL CREATE DATA!";
	}

}

?>
<!DOCTYPE html>
<html>
<head>
	<title>CREATE PHP</title>
	<style>
table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {background-color: red;}
</style>
</head>
<body>
	<form action="<?php $_SERVER['PHP_SELF']?>" method="POST">

		<h3>Tambah/Create data</h3>
		<hr>

		<label>nama</label>
		<input type="text" name="input_nama">

		<br>
		<br>

		<label>kelas</label>
		<input type="text" name="input_kelas">

		<br>
		<br>
		<input type="submit" name="Add" value="Add">
	</form>
</body>
</html>