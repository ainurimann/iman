<?php

$sql_connection  = mysqli_connect("localhost" , "root" ,null, "db_crud");

if ($sql_connection) {
	echo "CONNECTION BERJAYA";
}

?>